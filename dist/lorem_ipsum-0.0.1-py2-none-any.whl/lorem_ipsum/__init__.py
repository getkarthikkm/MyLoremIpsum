name = "lorem_ipsum"
import lorem_ipsum
import search_word
import model
import input
import tests

